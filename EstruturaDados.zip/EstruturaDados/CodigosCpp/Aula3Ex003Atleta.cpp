#include <iostream>
#include <cstring>
using namespace std;
int main()
{
    //definição da estrutura
    struct Aula3Ex003Atleta
    {
        char nomeAtleta[31], esporte[25], categoria[15], telefone[15];
        float ajudaCusto;
        int anoNas;
    };
    cadastro atleta; //declara atleta como uma variável tipo cadastro
    //Atribui valores aos membros
    strcpy(atleta.nomeAtleta, "Joao Lopes");
    strcpy(atleta.esporte, "Volley");
    strcpy(atleta.categoria, "Adulto");
    strcpy(atleta.telefone, "21 - 22334455");
    atleta.ajudaCusto=2000;
    atleta.anoNas=1989;

    //Limpando a tela
    system("clear");
    cout<<"\n=========================================================================";
    cout<<"\n Nome  : "<<atleta.nomeAtleta<<"                                        =";
    cout<<"\n= Esporte: "<<atleta.esporte<<"\t\tCategoria: "<<atleta.categoria<<"    =";
    cout<<"\n= Valor da ajuda de custo: "<<atleta.ajudaCusto<<"                      =";
    cout<<"\n= Telefone: "<<atleta.telefone<<"\t\tAno_nas: "<<atleta.anoNas<<"       =";
    cout<<"\n=========================================================================";

    cout<<"\n";
    system("pause");
    

}