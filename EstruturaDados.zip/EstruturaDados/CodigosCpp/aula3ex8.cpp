#include <iostream>
using namespace std;

struct cad
{
    char nome[31];
    int idade;
};

void idade2020 (int &id);

int main()
{
    cad atleta={"Joao Renato", 21};
    cout<<"\nAntes da chamada da função";
    cout <<"\nNome do atleta: "<< atleta.nome <<"\tIdade em 2010: " << atleta.idade;
    idade2020(atleta.idade);
    cout<<"\n\nDepois da chamada da função";
    cout <<"\nNome do atleta: "<< atleta.nome <<"\tIdade em 2020: " << atleta.idade;
    cout <<"\n\n\n";
    return(0);
}
