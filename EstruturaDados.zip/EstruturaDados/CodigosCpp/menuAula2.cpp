#include <iostream>
#include<windows.h>
using namespace std;
void menu()
{
    system("cls");
    cout<<"\nMenu\n";
    cout<<"\n1 - Pilha";
    cout<<"\n2 - Fila";
    cout<<"\n3 - Lista";
    cout<<"\n4 - Arvore";
    cout<<"\n5 - Grafo";
    cout<<"\n6 - Sair";
    cout<<"\nOpcao: ";
}
int main()
{ int op;
do
{   menu(); //chamada da função
    cin>>op;
    switch (op)
    {
    case 1: cout<<"\nMetodo de Acesso: LIFO\n";
        break;
    case 2: cout<<"\nMetodo de Acesso: FIFO\n";
        break;
    case 3: cout<<"\nVamos estudar Lista\n";
        break;
    case 4: cout<<"\nNao vamos estudar Arvore\n";
        break;
    case 5: cout<<"\nNao vamos estudar Grafo\n";
        break;
    case 6: cout<<"\nObrigado por Estudar\n";
        break;    
    default: cout<<"\nOpcao Invalida\n";
  }
  system ("pause");
} while (op != 6);
return 0;
}