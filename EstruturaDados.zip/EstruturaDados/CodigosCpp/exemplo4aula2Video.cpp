#include <iostream>
#include <cstdlib>
#include <cstring>
#include <windows.h>
using namespace std;

void msgRecebe(char msg[]);
int main()
{
    char str[] = "ESTRUTURA DE DADOS";
    msgRecebe(str); cout<<"\nDepois da funcao: "<<str<<endl;
    msgRecebe(str);
    system("pause > NULL");
}

void msgRecebe(char msg[])
{ int tam = strlen(msg);
  msg[0]='*'; //altera o primeiro caracter
   cout<<"\n"<<msg<< " tem " <<tam<< " caracteres.\n";
}