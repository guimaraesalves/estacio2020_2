#include <iostream>
using namespace std;

struct  cad
{
    int matricula;
    float CR;
};

void Exibe(cad AL);

int main()
{
    cad aluno;
    cout <<"\nMatricula do aluno: ";
    cin>>aluno.matricula;
    cout <<"\nDigite CR: ";
    cin >> aluno.CR;
    Exibe(aluno);

    return(0);
}
void Exibe(cad AL)
{
    system("cis");
    cout << "\nMatricula do aluno: "<< AL.matricula << "\tCR: " << AL.CR; 
    
}
