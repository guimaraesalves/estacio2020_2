// Construa uma função que receba o endereço de um vetor que armazena alturas de um
//grupo de atletas, seu tamanho e a altura mínima de corte, retornando a quantidade
// de atletas com a altura superior ou igual ao corte.

#include <iostream>
#include <windows.h>

using namespace std;

int contaMaioresQueH(double[], int tam, double altp);

int main()
{
    double alturas[4], procuraAltura;
    for (int x = 0; x < 4; x++)
    {
        cout << "\nAltura " << x + 1 << ": ";
        cin >> alturas[x];
    }
    cout << "\n\nQual a altura minima? ";
    cin >> procuraAltura;
    cout << "\nRelacao das Alturas\n";
    for (int x = 0; x < 4; x++)
        cout << alturas[x] << "\t";
    contaMaioresQueH(alturas, 4, procuraAltura);
    cout << "\n\nTotal das alturas maiores do que: " << contaMaioresQueH(alturas, 4, procuraAltura);
    cout << "\n\n";
    system("pause");
    return 0;
}

int contaMaioresQueH(double alts[], int tam, double altP)
{
    int conta = 0;
        for (int x = 0; x < tam; x++)
            if (alts[x] >= altP)
            conta++;
        return 0;
}
