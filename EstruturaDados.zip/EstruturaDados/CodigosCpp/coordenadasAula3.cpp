#include <iostream>
using namespace std;
int main()
{
    struct coordenadasAula3
    {
        int x, y;
    };
    coordenadasAula3 a={-5,2}, b={6,5};
    cout<<"\nCoordenadas de a("<<a.x<<", "<<a.y<<")";
    cout<<"\nCoordenadas de b("<<b.x<<", "<<b.y<<")";
    cout<<"\n\n";
    
    
}