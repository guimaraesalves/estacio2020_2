#include <iostream>
#include <cstring>
using namespace std;
int main()
{ //definicao de estrutura
   struct Aula4Ex002Passagem
   {
       char nomePassageiro[31], origem[15], destino[15], numeroPassagem[15], identidade[15], telefone[15];
   } passageiro1=("Mr Lopes, João", "Brasil", "Londres", "Gol 1234", "IFP22222222", "21233333333"),
     passageiro2=("Mrs Lopes, Tereza", "Brasil", "Paris", "Gol 1234", "IFP7777777", "22345678890"),
     passageiro3=("Mr Ferreira, Marcelo", "Brasil", "Lisboa", "Gol 1239", "IFP23784567", "2234567890"), ;

//limpando a tela
system("cls");
cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
cout<<"\nNome: "<<passageiro1.nomePassageiro;
cout<<"\nOrigem: "<<passageiro1.origem<<"\t\tDestino: "<<passageiro1.destino;
cout<<"\nNumero da Passagem: "<<passageiro1.numeroPassagem<<"\tIdentidade: "<<passageiro1.identidade<<"\tTelefone: "<<passageiro1.telefone;
cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";

cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
cout<<"\nNome: "<<passageiro2.nomePassageiro;
cout<<"\nOrigem: "<<passageiro2.origem<<"\t\tDestino: "<<passageiro2.destino;
cout<<"\nNumero da Passagem: "<<passageiro2.numeroPassagem<<"\tIdentidade: "<<passageiro2.identidade<<"\tTelefone: "<<passageiro2.telefone;
cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";

cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
cout<<"\nNome: "<<passageiro3.nomePassageiro;
cout<<"\nOrigem: "<<passageiro3.origem<<"\t\tDestino: "<<passageiro3.destino;
cout<<"\nNumero da Passagem: "<<passageiro3.numeroPassagem<<"\tIdentidade: "<<passageiro3.identidade<<"\tTelefone: "<<passageiro3.telefone;
cout<<"\n++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++";
cout<<"\n";
system("pause");
}