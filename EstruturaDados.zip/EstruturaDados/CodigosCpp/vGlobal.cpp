#include <iostream>
#include <windows.h>

using namespace std;
int main( int argc, char * argv[] )
{
 int x;
 cout << "\nNome do programa : " << argv[ 0 ];
 cout << "\nDemais nomes\n";
 //argc conta os demais argumentos na entrada
 for ( x= 1; x < argc; x++)
 cout << "\n" << x << " - " << argv[x];
 cout<<"\n\n";
 system("pause");
 return 0;
} 