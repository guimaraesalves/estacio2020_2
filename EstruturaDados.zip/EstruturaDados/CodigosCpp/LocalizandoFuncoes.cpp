#include <iostream>
#include <windows.h>
using namespace std;
void facil();  // declaração
void juntando(); //declaração
void legivel(); //declaração

void facil()
{
    cout<<"\nAcho que estou entendendo\n";    
}

void juntando()
{
    int x;
    for (x=1; x<=3; x++)
    {
        facil();
        legivel();
    }    
}

void legivel()
{
    cout<<"\nFica muito mais legivel\n";
}

int main()
{
    juntando();
    cout<<"\n\n";
    system("pause");
    return 0;
}