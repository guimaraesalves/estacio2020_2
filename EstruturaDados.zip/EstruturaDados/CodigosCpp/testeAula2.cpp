#include <windows.h>
#include <iostream>
#include <cmath>
#include <cstdlib>

using namespace std;

float n1, n2, n3, med;
float media (float, float, float);
void entrada();
void saida();
int main()
{
    entrada();
    saida();
        return 0;
}
float media(float a, float b, float c)
{return (a+b+c)/3;}
void entrada()
{
    cout<<"Entre com a 1a. nota: ";
    cin>>n1;
    cout<<"Entre com a 2a. nota: ";
    cin>>n2;
    cout<<"Entre com a 3a. nota: ";
    cin>>n3;
}
void saida()
{
    cout<<"A media : "<<media(n1, n2, n3);
}