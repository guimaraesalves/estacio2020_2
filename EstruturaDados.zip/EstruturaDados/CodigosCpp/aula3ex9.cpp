#include <iostream>
using namespace std;

int main()
{
    struct cad
    {
    char nome[31];
    };
    cad funcionario[3];
    //saida
    cout<<"\n\nEndereco da estrurura (nem coloquei o &): "<<funcionario;
    cout<<"\n\nEndereço da 1a variavel da estrutura    : "<<funcionario[0];
    cout<<"\n\nEndereço da 2a variavel da estrutura    : "<<funcionario[1];
    cout<<"\n\nEndereço da 3a variavel da estrutura    : "<<funcionario[2];
    cout <<"\n\n";
    system("pause");
    return (0);
    
}