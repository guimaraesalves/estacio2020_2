#include <windows.h>
#include <iostream>

using namespace std;

int main()
{
    int vetor[5] = {18, 23, 52, 13, 15};
    cout<<"\nValor do primeiro elemento : "<<vetor[0]<<end1;
    cout<<"\nEndereco do primeiro elemento: "<<&vetor[0]<<end1;
    cout<<"\nEnderco do vetor             : "<<&vetor<<end1;
    cout<<"\nVetor                        : "<<vetor;
    cout<<"\n\n";
    system ("pause");
    return 0;
}