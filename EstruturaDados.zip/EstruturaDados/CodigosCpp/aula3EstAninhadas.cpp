#include <iostream>
using namespace std;
struct data
{
    int dia, mes, ano;
};
int main()
{
struct pagto
{
   int codigo;
   float valor;
   data venc;
}promissoras[2];
}


