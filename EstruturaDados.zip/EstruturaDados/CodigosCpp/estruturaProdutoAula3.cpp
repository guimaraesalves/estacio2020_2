#include <iostream>
#include <cstring>
using namespace std;
int main()
{
    struct estruturaProdutoAula3
    {
        char nomeProd[21];
        float valor;
    }produto1={"martelo", 35.90}, produto2={"furadeira", 256.75}, aux;
    if (strcmp(produto1.nomeProd, produto2.nomeProd)>0)
    { aux= produto1; produto1=produto2; produto2=aux;}
    cout<<"\nNome do Produto1: "<<produto1.nomeProd<<"\t"<<produto1.valor;
    cout<<"\nNome do Produto2; "<<produto2.nomeProd<<"\t"<<produto2.valor;
    cout<<"\n\n";
    
    
}